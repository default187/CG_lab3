#ifndef MAIN_H_INCLUDED
#define MAIN_H_INCLUDED

#include <windows.h>
#include <gl/gl.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <string>
#include <malloc.h>
#include "stb_easy_font.h"
#include "menu.h"
#include "texture.h"

using namespace std;

int width =1080;
int height =720;

GLuint texture;
GLuint sprite;
GLuint background;

float gravity = 0.2;
float speed = 5.5;
float currentframe=2;
float chSiX;
float chSiY;
bool directional;
bool State=0;
int n=0;
int t=0;

typedef struct
{
    float x, y, dx, dy;
} Hero;

typedef struct
{
    float left, right, top, bottom, textX, textY;
} sritCoord;

Hero Charactr;
sritCoord vrtcoord;
sritCoord BackGroundCoord;

void Hero_Init(Hero *obj, float x1, float y1, float dx1, float dy1)
{
    obj->x=x1;
    obj->y=y1;
    obj->dx=dx1;
    obj->dy=dy1;
}

void Reflect (float *da, float *a, BOOL cond, float wall)
{
    if (!cond) return;
    *da*=-0; // ���� -0,1
    *a=wall;
}

void Hero_Move(Hero *obj)
{
    obj->y+=obj->dy;
    obj->x+=obj->dx;
    Reflect(&obj->dy, &obj->y, obj->y<0,0);
    obj->dy-=gravity;
    if (obj->x == 0) obj->x=3;
    if (GetKeyState(VK_LEFT)<0 && (obj->x>0) && State==1)
    {
        t = 2;
        currentframe+=0.15;
        obj->dx-=speed;
        obj->x+=obj->dx;
        obj->dx=0;
        if (currentframe>8) currentframe-=7;
        directional=1;
    }

    if (GetKeyState(VK_RIGHT)<0 && (obj->x<980) && State==1)
    {
        t = 2;
        currentframe+=0.15;
        obj->dx+=speed;
        obj->x+=obj->dx;
        obj->dx=0;
        if (currentframe>8) currentframe-=7;
        directional=0;
    }
    if (GetKeyState(VK_UP)<0 && (obj->y<100) && State==1)
    {
        t = 1;
        currentframe+=0.2;
        obj->dy = 6;
        obj->y+=obj->dy;
        if (currentframe>8) currentframe-=7;
        directional=0;
    }
}

void Sprite_animation(GLuint texture, int n, int t, Hero *obj)
{
    static float svertix[]= {0,0, 80,0, 80,100, 0,100};
    static float TexCord[]= {0,0, 0.12,0, 0.12,1, 0,1};
    glEnable(GL_TEXTURE_2D);
    glBindTexture(GL_TEXTURE_2D, texture);
    glEnable(GL_ALPHA_TEST);
    glAlphaFunc(GL_GREATER, 0.7);

    glEnableClientState(GL_VERTEX_ARRAY);
    glEnableClientState(GL_TEXTURE_COORD_ARRAY);

    glVertexPointer(2,GL_FLOAT,0,svertix);
    glTexCoordPointer(2,GL_FLOAT,0,TexCord);

    static float spriteXsize=640;
    static float spriteYsize=300;
    static float charsizey=100;
    static float charsizex=80;
    vrtcoord.left=(charsizex*n)/spriteXsize;
    vrtcoord.right=vrtcoord.left+(charsizex/spriteXsize);
    vrtcoord.top=(charsizey*t)/spriteYsize;
    vrtcoord.bottom=vrtcoord.top+(charsizey/spriteYsize);

    TexCord[1] = TexCord[3] = vrtcoord.bottom;
    TexCord[5] = TexCord[7] = vrtcoord.top;

    if (GetKeyState(VK_LEFT)<0 && State==1)
    {
        TexCord[2] = TexCord[4] = vrtcoord.left;
        TexCord[0] = TexCord[6] = vrtcoord.right;
    }
    if (GetKeyState(VK_RIGHT)<0 && State==1)
    {
        TexCord[0] = TexCord[6] = vrtcoord.left;
        TexCord[2] = TexCord[4] = vrtcoord.right;
    }

    glDrawArrays(GL_TRIANGLE_FAN,0,4);
    glDisable(GL_ALPHA_TEST);

    glDisableClientState(GL_VERTEX_ARRAY);
    glDisableClientState(GL_TEXTURE_COORD_ARRAY);
    glPopMatrix();

    chSiX=charsizex;
    chSiY=charsizey;
}

void Main_Init()
{
    Hero_Init(&Charactr, width/2.0,height/2.0,0,0);
    Load_Texture("image.png", &sprite, GL_CLAMP, GL_CLAMP, GL_NEAREST);
    Load_Texture("background.png", &background, GL_REPEAT, GL_CLAMP, GL_NEAREST);
}

void Menu_Init(){
    Menu_AddButton("Play", 10.0,10.0,100.0,30.0, 2);
    Menu_AddButton("Pause", 130.0,10.0,100.0,30.0,2);
    Menu_AddButton("Quit", 250.0,10.0,100.0,30.0,2);
}

void Show_Background(GLuint texture, Hero *obj, sritCoord *bg)
{
    static float svertix[]= {-1080,0, -1080,700, 1080*2,700, 1080*2,0};
    static float TexCord[]= {-1,1, -1,0, 2,0, 2,1 };
    glClearColor(0,0,0,0);
    glEnable(GL_TEXTURE_2D);
    glBindTexture(GL_TEXTURE_2D, texture);
    glEnableClientState(GL_VERTEX_ARRAY);
    glEnableClientState(GL_TEXTURE_COORD_ARRAY);

    glVertexPointer(2,GL_FLOAT,0,svertix);
    glTexCoordPointer(2,GL_FLOAT,0,TexCord);
    glDrawArrays(GL_TRIANGLE_FAN,0,4);

    glDisableClientState(GL_VERTEX_ARRAY);
    glDisableClientState(GL_TEXTURE_COORD_ARRAY);
}

void MouseDown()
{
    int buttonId = Menu_MouseDown();
    if(buttonId<0) return;
    char *name = Menu_GetButtonName(buttonId);
    printf("%s\n",name, &buttonId);
    switch (buttonId)
    {
    case 0:
        if (State==0) State=1;
        break;
    case 1:
        if (State==1) State=0;
        break;
    case 2:
        PostQuitMessage(0);
        break;
}
}

void Hero_Show(Hero *obj)
{
    glPushMatrix();
    glTranslatef(obj->x,obj->y,0);
    Sprite_animation(sprite, currentframe, t, &Charactr);
    glPopMatrix();

}

#endif // MAIN_H_INCLUDED
